@echo off

start cmd /k "cd backend && npm start"
start cmd /k "cd frontend && npm start"

timeout /t 5 >nul
start http://localhost:3000